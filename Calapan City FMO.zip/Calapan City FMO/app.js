// app.js
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');

const landingRoutes = require('./routes/landingRoutes');
const authRoutes = require('./routes/authRoutes');
const dashboardRoutes = require('./routes/dashboard');
const registerRoutes = require('./routes/register'); 
const aquacultureRoutes = require('./routes/aquacultureRoutes');
const fisherfolkRoutes = require('./routes/fisherfolkRoutes');
const catchReportRoutes = require('./routes/catchReportRoutes');
const fishingActivityRoutes = require('./routes/fishingActivityRoutes');
const enforcementComplianceRoutes = require('./routes/enforcementComplianceRoutes');
const violationNotificationRoutes = require('./routes/violationNotificationRoutes');
const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', './views');

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));  // For parsing application/x-www-form-urlencoded (HTML forms)
app.use(express.json());  // For parsing application/json
 
// Session middleware
app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true
}));

// Routes
app.get('/', (req, res) => {
    if (req.session.userId) {
      return res.redirect(`/dashboard/${req.session.role}`);
    }
    res.redirect('/auth/login');
  });
app.use('/auth', authRoutes);
app.use('/dashboard', dashboardRoutes);
app.use('/register', registerRoutes);  // For handling registration routes (including fisherfolk, aquaculture)
app.use('/aquaculture', aquacultureRoutes);  // Only the aquaculture-specific routes
app.use('/register/fisherfolk', fisherfolkRoutes);
app.use('/catch-report-review', catchReportRoutes);
app.use('/fishing-activity-tracking', fishingActivityRoutes);
app.use('/enforcement-compliance-logging', enforcementComplianceRoutes);
app.use('/violation-notification-system', violationNotificationRoutes);




const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server started on port http://localhost:${PORT}`);
});
 