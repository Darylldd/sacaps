// controllers/violationNotificationController.js

const violationNotificationModel = require('../models/violationNotificationModel');

function violationNotificationSystem(req, res) {
  const filters = {
    reportId: req.query.reportId || "",
    violation: req.query.violation || "",
    status: req.query.status || "",
    date: req.query.date || "",
  };

  const sortBy = req.query.sortBy || null;
  const reports = violationNotificationModel.getViolationReports(filters, sortBy);
  res.render('violationNotification', { reports, filters, sortBy });
}

module.exports = {
  violationNotificationSystem,
};
