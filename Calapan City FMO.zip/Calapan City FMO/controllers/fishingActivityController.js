// controllers/fishingActivityController.js

const fishingActivityModel = require('../models/fishingActivityModel');

function fishingActivityTracking(req, res) {
  const filters = {
    date: req.query.date || "",
    location: req.query.location || "",
    activity: req.query.activity || "",
  };

  const sortBy = req.query.sortBy || null;

  const activities = fishingActivityModel.getFishingActivities(filters, sortBy);
  res.render('fishingActivity', { activities, filters, sortBy });
}

module.exports = {
  fishingActivityTracking,
};
