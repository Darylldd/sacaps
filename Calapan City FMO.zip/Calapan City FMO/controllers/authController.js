// controllers/authController.js
const pool = require('../models/db');  // Use our pool
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const bcrypt = require('bcrypt');

// Configure your email transporter (adjust settings for your SMTP server)
let transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com', // replace with your SMTP host
  port: 587,
  secure: false,
  auth: {
    user: 'aash100227@gmail.com',
    pass: 'aprm fmwl jlni vbib'
  }
});

// GET /auth/login
exports.getLogin = (req, res) => {
  res.render('login', { title: 'Log In' });
};

// POST /auth/login
exports.postLogin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const [rows] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.send('User not found.');
    }
    const user = rows[0];
    if (!user.is_verified) {
      return res.send('Please verify your email before logging in.');
    }
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.send('Incorrect password.');
    }

    req.session.userId = user.id;
    req.session.role = user.role;
    req.session.user = { name: user.name, email: user.email }; // Store user info in session

    // Redirect based on user role
    if (user.role === 'admin') {
      return res.redirect('/dashboard/admin');
    } else {
      return res.redirect('/dashboard/user');
    }
  } catch (err) {
    console.error(err);
    res.send('Error logging in.');
  }
};


// GET /auth/signup
exports.getSignup = (req, res) => {
  res.render('signup', { title: 'Sign Up' });
};

// POST /auth/signup
exports.postSignup = async (req, res) => {
  const { name, email, password, role } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const verificationToken = crypto.randomBytes(32).toString('hex');
  try {
    await pool.execute(
      'INSERT INTO users (name, email, password, role, is_verified, verification_token) VALUES (?, ?, ?, ?, ?, ?)',
      [name, email, hashedPassword, role, false, verificationToken]
    );

    // Send verification email
    const verificationLink = `http://localhost:3000/auth/verify-email?token=${verificationToken}&email=${email}`;
    await transporter.sendMail({
      from: '"FMO" <no-reply@fmo.com>',
      to: email,
      subject: 'Email Verification',
      text: `Click the following link to verify your email: ${verificationLink}`
    });
    res.send('Signup successful. Please check your email to verify your account.');
  } catch (err) {
    console.error(err);
    res.send('Error during signup.');
  }
};

// GET /auth/verify-email
exports.verifyEmail = async (req, res) => {
  const { token, email } = req.query;
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE email = ? AND verification_token = ?',
      [email, token]
    );
    if (rows.length === 0) {
      return res.send('Invalid token or email.');
    }
    await pool.execute(
      'UPDATE users SET is_verified = ?, verification_token = NULL WHERE email = ?',
      [true, email]
    );
    res.send('Email verified successfully. You can now log in.');
  } catch (err) {
    console.error(err);
    res.send('Error verifying email.');
  }
};

// GET /auth/forgot-password
exports.getForgotPassword = (req, res) => {
  res.render('forgot-password', { title: 'Forgot Password' });
};

// POST /auth/forgot-password
exports.postForgotPassword = async (req, res) => {
  const { email } = req.body;
  const resetToken = crypto.randomBytes(32).toString('hex');
  try {
    const [rows] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.send('No user with that email.');
    }
    const expiry = Date.now() + 3600000; // token valid for 1 hour
    await pool.execute(
      'UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?',
      [resetToken, expiry, email]
    );
    const resetLink = `http://localhost:3000/auth/reset-password?token=${resetToken}&email=${email}`;
    await transporter.sendMail({
      from: '"FMO" <no-reply@fmo.com>',
      to: email,
      subject: 'Password Reset',
      text: `Click the following link to reset your password: ${resetLink}`
    });
    res.send('Password reset link sent. Please check your email.');
  } catch (err) {
    console.error(err);
    res.send('Error during password reset.');
  }
};

// GET /auth/reset-password
exports.getResetPassword = (req, res) => {
  const { token, email } = req.query;
  res.render('reset-password', { title: 'Reset Password', token, email });
};

// POST /auth/reset-password
exports.postResetPassword = async (req, res) => {
  const { token, email, password } = req.body;
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE email = ? AND reset_token = ? AND reset_token_expiry > ?',
      [email, token, Date.now()]
    );
    if (rows.length === 0) {
      return res.send('Invalid or expired token.');
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    await pool.execute(
      'UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE email = ?',
      [hashedPassword, email]
    );
    res.send('Password reset successfully. You can now log in.');
  } catch (err) {
    console.error(err);
    res.send('Error resetting password.');
  }
};

// GET /auth/logout
exports.logout = (req, res) => {
  req.session.destroy();
  res.redirect('/');
};
