// controllers/catchReportController.js

const catchReportModel = require('../models/catchReportModel');

function catchReportReview(req, res) {
  // Extract filter and sorting options from query parameters
  const filters = {
    species: req.query.species || "",
    location: req.query.location || "",
    status: req.query.status || "",
    date: req.query.date || "",
  };

  // sortBy can be passed as a query parameter, e.g., ?sortBy=species
  const sortBy = req.query.sortBy || null;

  // Retrieve the filtered and sorted reports from the model
  const reports = catchReportModel.getCatchReports(filters, sortBy);

  // Render the EJS view, passing the data
  res.render('catchReportReview', { reports, filters, sortBy });
}

module.exports = {
  catchReportReview,
};
