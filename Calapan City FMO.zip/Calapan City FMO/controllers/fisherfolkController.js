// controllers/fisherfolkController.js
const fisherfolkModel = require('../models/fisherfolkModel');

exports.registerFisherfolk = (req, res) => {
    const { name, contact_info, fishing_methods, fishing_zone, license_number } = req.body;

    // Pass data to the model to save in the database
    fisherfolkModel.registerFisherfolk({ name, contact_info, fishing_methods, fishing_zone, license_number }, (err, results) => {
        if (err) {
            return res.status(500).send('Error registering fisherfolk');
        }
        res.redirect('/register/fisherfolk');  // Redirect to the registration page or another page
    });
};
