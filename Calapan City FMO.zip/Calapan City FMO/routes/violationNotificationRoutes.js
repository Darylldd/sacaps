// routes/violationNotificationRoutes.js
const express = require('express');
const router = express.Router();
const violationNotificationController = require('../controllers/violationNotificationController');

router.get('/', violationNotificationController.violationNotificationSystem);

module.exports = router;
