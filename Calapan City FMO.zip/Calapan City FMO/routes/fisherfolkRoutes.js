// routes/fisherfolkRoutes.js
const express = require('express');
const router = express.Router();
const fisherfolkController = require('../controllers/fisherfolkController');

// Route for the registration form
router.get('/register/fisherfolk', (req, res) => {
    res.render('register-fisherfolk');  // Render the Fisherfolk registration page
});

// Route for submitting the registration form
router.post('/register/fisherfolk', fisherfolkController.registerFisherfolk);

module.exports = router;
