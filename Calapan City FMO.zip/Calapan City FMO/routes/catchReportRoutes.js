// routes/catchReportRoutes.js
const express = require('express');
const router = express.Router();
const catchReportController = require('../controllers/catchReportController');

// Instead of: router.get('/catch-report-review', catchReportController.catchReportReview);
// Use the relative path:
router.get('/', catchReportController.catchReportReview);

module.exports = router;
