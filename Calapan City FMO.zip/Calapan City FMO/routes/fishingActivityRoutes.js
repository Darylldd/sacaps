// routes/fishingActivityRoutes.js
const express = require('express');
const router = express.Router();
const fishingActivityController = require('../controllers/fishingActivityController');

router.get('/', fishingActivityController.fishingActivityTracking);

module.exports = router;
