// models/fishingActivityModel.js

const fishingActivities = [
    { date: "2025-02-15", time: "08:00", location: "River Bend", activity: "Started Fishing" },
    { date: "2025-02-15", time: "12:00", location: "Lakeview", activity: "Paused" },
    { date: "2025-02-16", time: "09:00", location: "Harbor", activity: "Ended Fishing" },
    // ... more data or real database queries
  ];
  
  function getFishingActivities(filters, sortBy) {
    let results = [...fishingActivities];
  
    // Filtering by date, location, and activity
    if (filters) {
      if (filters.date) {
        results = results.filter(act => act.date === filters.date);
      }
      if (filters.location) {
        results = results.filter(act =>
          act.location.toLowerCase().includes(filters.location.toLowerCase())
        );
      }
      if (filters.activity) {
        results = results.filter(act =>
          act.activity.toLowerCase().includes(filters.activity.toLowerCase())
        );
      }
    }
  
    // Sorting
    if (sortBy) {
      results.sort((a, b) => {
        if (a[sortBy] < b[sortBy]) return -1;
        if (a[sortBy] > b[sortBy]) return 1;
        return 0;
      });
    }
  
    return results;
  }
  
  module.exports = {
    getFishingActivities,
  };
  