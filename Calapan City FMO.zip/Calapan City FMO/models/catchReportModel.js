// models/catchReportModel.js

// Dummy data representing catch reports
const catchReports = [
    { species: "Salmon", quantity: 10, location: "North Bay", status: "Under Review", date: "2025-02-15" },
    { species: "Trout", quantity: 5, location: "Lakeview", status: "Approved", date: "2025-02-14" },
    { species: "Carp", quantity: 7, location: "River Bend", status: "Flagged", date: "2025-02-13" },
    // ... add more dummy data or connect to your database
  ];
  
  /**
   * Retrieves catch reports with optional filtering and sorting.
   * @param {Object} filters - Filter criteria.
   * @param {string} sortBy - Field name to sort by.
   * @returns {Array} Filtered and sorted catch reports.
   */
  function getCatchReports(filters, sortBy) {
    let results = [...catchReports];
  
    // Filtering
    if (filters) {
      if (filters.species) {
        results = results.filter(report =>
          report.species.toLowerCase().includes(filters.species.toLowerCase())
        );
      }
      if (filters.location) {
        results = results.filter(report =>
          report.location.toLowerCase().includes(filters.location.toLowerCase())
        );
      }
      if (filters.status) {
        results = results.filter(report =>
          report.status.toLowerCase() === filters.status.toLowerCase()
        );
      }
      if (filters.date) {
        results = results.filter(report => report.date === filters.date);
      }
    }
  
    // Sorting
    if (sortBy) {
      results.sort((a, b) => {
        if (a[sortBy] < b[sortBy]) return -1;
        if (a[sortBy] > b[sortBy]) return 1;
        return 0;
      });
    }
  
    return results;
  }
  
  module.exports = {
    getCatchReports,
  };
  