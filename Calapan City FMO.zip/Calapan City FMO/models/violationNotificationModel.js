// models/violationNotificationModel.js

const violationReports = [
    { reportId: "VR-001", violation: "Illegal netting", status: "Pending", submittedBy: "Fisher John", date: "2025-02-11" },
    { reportId: "VR-002", violation: "Overfishing", status: "Reviewed", submittedBy: "Fisher Jane", date: "2025-02-12" },
    // ... more dummy data
  ];
  
  function getViolationReports(filters, sortBy) {
    let results = [...violationReports];
  
    // Filtering by reportId, violation, status, and date
    if (filters) {
      if (filters.reportId) {
        results = results.filter(report =>
          report.reportId.toLowerCase().includes(filters.reportId.toLowerCase())
        );
      }
      if (filters.violation) {
        results = results.filter(report =>
          report.violation.toLowerCase().includes(filters.violation.toLowerCase())
        );
      }
      if (filters.status) {
        results = results.filter(report =>
          report.status.toLowerCase() === filters.status.toLowerCase()
        );
      }
      if (filters.date) {
        results = results.filter(report => report.date === filters.date);
      }
    }
  
    // Sorting
    if (sortBy) {
      results.sort((a, b) => {
        if (a[sortBy] < b[sortBy]) return -1;
        if (a[sortBy] > b[sortBy]) return 1;
        return 0;
      });
    }
  
    return results;
  }
  
  module.exports = {
    getViolationReports,
  };
  