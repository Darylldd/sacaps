// models/fisherfolkModel.js
const db = require('./db');  // Import your DB connection

// Function to register a new fisherfolk
module.exports.registerFisherfolk = (data, callback) => {
    const { name, contact_info, fishing_methods, fishing_zone, license_number } = data;
    const query = `INSERT INTO fisherfolk (name, contact_info, fishing_methods, fishing_zone, license_number) 
                   VALUES (?, ?, ?, ?, ?)`;
    db.query(query, [name, contact_info, fishing_methods, fishing_zone, license_number], (err, results) => {
        if (err) {
            return callback(err);
        }
        return callback(null, results);
    });
};
