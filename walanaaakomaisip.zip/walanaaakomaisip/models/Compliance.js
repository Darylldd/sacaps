const db = require('../config/db');

// Fetch all violations
exports.getAllViolations = async () => {
    const [rows] = await db.execute('SELECT * FROM violations');
    return rows;
};

// Add a new violation
exports.logViolation = async (officerName, fisherfolkId, violationType, description, penaltyAmount) => {
    await db.execute(
        'INSERT INTO violations (officer_name, fisherfolk_id, violation_type, description, penalty_amount) VALUES (?, ?, ?, ?, ?)',
        [officerName, fisherfolkId, violationType, description, penaltyAmount]
    );
};

// Update compliance status
exports.updateComplianceStatus = async (id, status) => {
    await db.execute('UPDATE violations SET compliance_status = ? WHERE id = ?', [status, id]);
};
