const db = require('../config/db'); // Replace with your DB connection

const AquacultureFacility = {
    create: async (facilityData) => {
        const sql = `
            INSERT INTO aquaculture_facilities (facility_name, species, location, production_capacity)
            VALUES (?, ?, ?, ?)
        `;
        const [result] = await db.execute(sql, [
            facilityData.facility_name,
            facilityData.species,
            facilityData.location,
            facilityData.production_capacity,
        ]);
        return result;
    },

    getAll: async () => {
        const sql = `SELECT * FROM aquaculture_facilities ORDER BY created_at DESC`;
        const [rows] = await db.execute(sql);
        return rows;
    },
};

module.exports = AquacultureFacility;
