const pool = require('../config/db');

class User {
    static async create(data) {
        const sql = `INSERT INTO users (full_name, date_of_birth, gender, email, phone_number, street_address, city, state, country, emergency_contact, username, password, profile_picture)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        const values = [
            data.full_name, data.date_of_birth, data.gender, data.email, data.phone_number,
            data.street_address, data.city, data.state, data.country, data.emergency_contact,
            data.username, data.password, data.profile_picture
        ];
        return pool.query(sql, values);
    }

    // Add the findByUsername method
    static async findByUsername(username) {
        const sql = 'SELECT * FROM users WHERE username = ?';
        const values = [username];
        const [rows] = await pool.query(sql, values);
        return rows;
    }
}

module.exports = User;
