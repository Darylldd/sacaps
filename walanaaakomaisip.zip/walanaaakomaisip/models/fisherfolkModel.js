const db = require('../config/db'); // Assuming a database config file is available

// Insert fisherfolk data into the database
exports.createFisherfolk = async ({ name, address, contact_number, email }) => {
    const [result] = await db.query(
        'INSERT INTO fisherfolk (name, address, contact_number, email) VALUES (?, ?, ?, ?)',
        [name, address, contact_number, email]
    );
    return result.insertId; // Return the newly created fisherfolk ID
};

// Insert vessel data into the database
exports.createVessel = async ({ fisherfolk_id, vessel_name, registration_number, length, capacity, operational_zone }) => {
    await db.query(
        'INSERT INTO vessels (fisherfolk_id, vessel_name, registration_number, length, capacity, operational_zone) VALUES (?, ?, ?, ?, ?, ?)',
        [fisherfolk_id, vessel_name, registration_number, length, capacity, operational_zone]
    );
};

// Fetch all fisherfolk and their associated vessels
exports.getAllFisherfolk = async () => {
    const [rows] = await db.query(
        `SELECT f.id AS fisherfolk_id, f.name, f.address, f.contact_number, f.email, 
                v.id AS vessel_id, v.vessel_name, v.registration_number, v.length, 
                v.capacity, v.operational_zone 
         FROM fisherfolk f 
         LEFT JOIN vessels v ON f.id = v.fisherfolk_id`
    );
    return rows;
};

// Delete a fisherfolk record and cascade delete associated vessels
exports.deleteFisherfolkById = async (id) => {
    await db.query('DELETE FROM fisherfolk WHERE id = ?', [id]);
};

exports.getFisherfolkById = async (id) => {
    const [rows] = await db.query(
        `SELECT * FROM fisherfolk f 
         LEFT JOIN vessels v ON f.id = v.fisherfolk_id 
         WHERE f.id = ?`, [id]
    );
    return rows[0];
};

exports.updateFisherfolk = async (id, { name, address, contact_number, email, vessel_name, registration_number, length, capacity, operational_zone }) => {
    await db.query(
        `UPDATE fisherfolk SET name = ?, address = ?, contact_number = ?, email = ? WHERE id = ?`,
        [name, address, contact_number, email, id]
    );

    await db.query(
        `UPDATE vessels SET vessel_name = ?, registration_number = ?, length = ?, capacity = ?, operational_zone = ? WHERE fisherfolk_id = ?`,
        [vessel_name, registration_number, length, capacity, operational_zone, id]
    );
};
