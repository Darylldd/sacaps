const axios = require('axios');

// Replace with your WeatherAPI key
const WEATHER_API_KEY = '933a5f62b6834a0f856135311250801';
const BASE_URL = 'http://api.weatherapi.com/v1';

exports.getWeather = async (location) => {
    try {
        const response = await axios.get(`${BASE_URL}/forecast.json`, {
            params: {
                key: WEATHER_API_KEY,
                q: location, // Location (e.g., city name or coordinates)
                days: 7, // Number of days to forecast (max 10 for free tier)
            }
        });

        const data = response.data;

        // Extract current weather and 7-day forecast
        const currentWeather = {
            location: data.location.name,
            country: data.location.country,
            temperature: data.current.temp_c,
            condition: data.current.condition.text,
            windSpeed: data.current.wind_kph,
            windDirection: data.current.wind_dir,
        };

        const forecast = data.forecast.forecastday.map((day) => ({
            date: day.date,
            dayOfWeek: new Date(day.date).toLocaleDateString('en-US', { weekday: 'long' }),
            maxTemp: day.day.maxtemp_c,
            minTemp: day.day.mintemp_c,
            condition: day.day.condition.text,
            icon: day.day.condition.icon,
        }));

        return { currentWeather, forecast };
    } catch (error) {
        console.error('Error fetching weather data:', error.message);
        return null;
    }
};
