const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Import routes
const authRoutes = require('./routes/authRoutes');
const fisherfolkRoutes = require('./routes/fisherfolkRoutes');
const aquacultureRoutes = require('./routes/aquacultureRoutes');
const complianceRoutes = require('./routes/complianceRoutes');
// Set view engine to EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use(authRoutes);
app.use('/fisherfolk', fisherfolkRoutes);
app.use('/aquaculture', aquacultureRoutes);
app.use('/compliance', complianceRoutes);
// Default route
app.get('/', (req, res) => {
    res.redirect('/register');
});

// Server
const PORT = 3001;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
 