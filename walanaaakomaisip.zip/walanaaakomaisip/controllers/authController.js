const User = require('../models/userModel');
const Admin = require('../models/adminModel');
const weatherUtil = require('../config/weather');
const bcrypt = require('bcrypt');

exports.showRegisterForm = (req, res) => {
    res.render('register');
};

exports.handleRoleSelection = (req, res) => {
    const { role, full_name, date_of_birth, gender } = req.body;

    if (role === 'admin') {
        res.render('adminForm', { full_name, date_of_birth, gender });
    } else if (role === 'user') {
        res.render('userForm', { full_name, date_of_birth, gender });
    } else {
        res.status(400).send('Invalid role selected');
    }
};

exports.handleAdminRegister = async (req, res) => {
    const data = req.body;

    try {
        data.password = await bcrypt.hash(data.password, 10);
        await Admin.create(data);
        res.redirect('/login');
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.handleUserRegister = async (req, res) => {
    const data = req.body;

    try {
        data.password = await bcrypt.hash(data.password, 10);
        await User.create(data);
        res.redirect('/login');
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.showLoginForm = (req, res) => {
    res.render('login');
};

exports.handleLogin = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Check if the user exists (search in both user and admin tables)
        const [admin] = await Admin.findByUsername(username);
        const [user] = await User.findByUsername(username);

        const account = admin || user;

        if (!account) {
            return res.status(401).send('Invalid username or password');
        }

        // Compare password
        const isPasswordValid = await bcrypt.compare(password, account.password);
        if (!isPasswordValid) {
            return res.status(401).send('Invalid username or password');
        }

        // Fetch weather data for the specific location (e.g., "Calapan City")
        const weatherData = await weatherUtil.getWeather('Calapan City');

        // Redirect or render the dashboard depending on the role
        if (admin) {
            res.render('adminDashboard', { fullName: admin.full_name, weather: weatherData });
        } else if (user) {
            res.render('userDashboard', { fullName: user.full_name, weather: weatherData });
        }
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

exports.getDashboard = async (req, res) => {
    // Fetch weather data for a specific location (e.g., "Calapan City")
    const weatherData = await weatherUtil.getWeather('Calapan City');

    // Render the dashboard page with weather data
    res.render('dashboard', { weather: weatherData });
};
