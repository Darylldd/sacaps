const Compliance = require('../models/Compliance');

// Render the log violation form
exports.renderLogViolation = (req, res) => {
    res.render('compliance/logViolation', { title: 'Log Violation' });
};

// Log a new violation
exports.logViolation = async (req, res) => {
    const { officerName, fisherfolkId, violationType, description, penaltyAmount } = req.body;
    await Compliance.logViolation(officerName, fisherfolkId, violationType, description, penaltyAmount);
    res.redirect('/compliance/violations');
};

// View all violations
exports.viewViolations = async (req, res) => {
    const violations = await Compliance.getAllViolations();
    res.render('compliance/viewViolations', { title: 'View Violations', violations });
};

// Update compliance status
exports.updateComplianceStatus = async (req, res) => {
    const { id, status } = req.body;
    await Compliance.updateComplianceStatus(id, status);
    res.redirect('/compliance/violations');
};

// Render the compliance status page
exports.renderComplianceStatus = async (req, res) => {
    const violations = await Compliance.getAllViolations();
    res.render('compliance/complianceStatus', { title: 'Compliance Status', violations });
};
