const AquacultureFacility = require('../models/aquacultureFacilityModel');

const aquacultureController = {
    showRegistrationForm: (req, res) => {
        res.render('aquaculture/register');
    },
    
    registerFacility: async (req, res) => {
        try {
            const { facility_name, species, location, production_capacity } = req.body;
            await AquacultureFacility.create({ facility_name, species, location, production_capacity });
            res.status(200).json({ success: true, message: 'Facility registered successfully!' });
        } catch (error) {
            console.error('Error registering facility:', error);
            res.status(500).json({ success: false, message: 'Failed to register facility. Please try again later.' });
        }
    },

    listFacilities: async (req, res) => {
        try {
            const facilities = await AquacultureFacility.getAll();
            res.render('aquaculture/list', { facilities });
        } catch (error) {
            console.error('Error fetching facilities:', error);
            res.status(500).send('Internal Server Error');
        }
    },
};

module.exports = aquacultureController;
