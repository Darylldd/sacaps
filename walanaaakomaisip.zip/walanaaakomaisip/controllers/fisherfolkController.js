const fisherfolkModel = require('../models/fisherfolkModel');

// Render registration form
exports.showRegistrationForm = (req, res) => {
    res.render('fisherfolk/register', { title: 'Register Fisherfolk and Vessel' });
};

// Handle form submission
exports.registerFisherfolk = async (req, res) => {
    const { name, address, contact_number, email, vessel_name, registration_number, length, capacity, operational_zone } = req.body;

    try {
        // Save fisherfolk and vessel details
        const fisherfolkId = await fisherfolkModel.createFisherfolk({
            name,
            address,
            contact_number,
            email
        });

        await fisherfolkModel.createVessel({
            fisherfolk_id: fisherfolkId,
            vessel_name,
            registration_number,
            length,
            capacity,
            operational_zone
        });

        res.render('fisherfolk/success', { title: 'Registration Successful' });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error registering fisherfolk and vessel.');
    }
};


// Fetch and display all fisherfolk and vessel records
exports.listFisherfolk = async (req, res) => {
    try {
        const fisherfolk = await fisherfolkModel.getAllFisherfolk();
        const fullName = req.user ? req.user.fullName : 'Admin'; // Replace with actual user fetching logic
        res.render('fisherfolk/list', { title: 'Fisherfolk and Vessels', fisherfolk, fullName });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error fetching fisherfolk data.');
    }
};

// Delete a fisherfolk record
exports.deleteFisherfolk = async (req, res) => {
    const { id } = req.params;
    try {
        await fisherfolkModel.deleteFisherfolkById(id);
        res.redirect('/fisherfolk/list');
    } catch (error) {
        console.error(error);
        res.status(500).send('Error deleting fisherfolk record.');
    }
};

// Render the edit form
exports.editFisherfolkForm = async (req, res) => {
    const { id } = req.params;
    try {
        const fisherfolk = await fisherfolkModel.getFisherfolkById(id);
        res.render('fisherfolk/edit', { title: 'Edit Fisherfolk', fisherfolk });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error fetching fisherfolk data.');
    }
};

// Update fisherfolk data
exports.updateFisherfolk = async (req, res) => {
    const { id } = req.params;
    const { name, address, contact_number, email, vessel_name, registration_number, length, capacity, operational_zone } = req.body;

    try {
        await fisherfolkModel.updateFisherfolk(id, {
            name, address, contact_number, email, vessel_name, registration_number, length, capacity, operational_zone
        });
        res.redirect('/fisherfolk/list');
    } catch (error) {
        console.error(error);
        res.status(500).send('Error updating fisherfolk data.');
    }
};
