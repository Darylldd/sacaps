const express = require('express');
const router = express.Router();
const fisherfolkController = require('../controllers/fisherfolkController');

// Show registration form
router.get('/register', fisherfolkController.showRegistrationForm);

// Handle form submission
router.post('/register', fisherfolkController.registerFisherfolk);

// List fisherfolk and vessels
router.get('/list', fisherfolkController.listFisherfolk);

// Delete a fisherfolk record
router.post('/delete/:id', fisherfolkController.deleteFisherfolk);

router.get('/edit/:id', fisherfolkController.editFisherfolkForm);
router.post('/edit/:id', fisherfolkController.updateFisherfolk);

module.exports = router;
