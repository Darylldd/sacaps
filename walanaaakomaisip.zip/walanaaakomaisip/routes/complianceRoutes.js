const express = require('express');
const complianceController = require('../controllers/complianceController');
const router = express.Router();

// Route to render the log violation form
router.get('/log', complianceController.renderLogViolation);

// Route to log a new violation
router.post('/log', complianceController.logViolation);

// Route to view all violations
router.get('/violations', complianceController.viewViolations);

// Route to update compliance status
router.post('/update-status', complianceController.updateComplianceStatus);

// Route to view compliance status
router.get('/status', complianceController.renderComplianceStatus);


module.exports = router;
