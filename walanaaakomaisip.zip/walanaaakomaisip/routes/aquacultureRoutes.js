const express = require('express');
const router = express.Router();
const aquacultureController = require('../controllers/aquacultureController');

router.get('/register', aquacultureController.showRegistrationForm);
router.post('/register', aquacultureController.registerFacility);
router.get('/facilities', aquacultureController.listFacilities); //alternative access to the list or table

router.get('/list', aquacultureController.listFacilities);
module.exports = router;
