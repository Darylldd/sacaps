const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.get('/register', authController.showRegisterForm);
router.post('/register/role', authController.handleRoleSelection);
router.post('/register/admin', authController.handleAdminRegister);
router.post('/register/user', authController.handleUserRegister);
router.get('/login', authController.showLoginForm);
router.post('/login', authController.handleLogin);

router.get('/dashboard', authController.getDashboard);

module.exports = router;
